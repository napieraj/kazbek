# acme relay plugin
class Plugin:
    pass
